// ARQUIVO: src/pages/Operacao.tsx

import { useEffect, useMemo, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import {
  AlertTriangle,
  BarChart3,
  Camera,
  ChevronLeft,
  ChevronRight,
  History,
  MapPin,
  Package,
  QrCode,
  Search,
  SlidersHorizontal,
  Truck,
  User,
  UserX,
  Users,
  X,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";

import PageHeader from "../components/ui/PageHeader";
import StatusBadge from "../components/ui/StatusBadge";
import {
  listarPacotes,
  nomeTipo,
  timestampMs,
} from "../services/pacotes";
import { auth, db } from "../services/firebase/firebase";
import { StatusPacote } from "../types";

type Visualizacao = "QR" | "USUARIOS" | "SLA";

const STATUS_FILTRO: {
  status: StatusPacote;
  label: string;
  color: string;
}[] = [
  { status: "COLETADO", label: "COLETADO", color: "#c9a227" },
  { status: "ROTA", label: "ROTA", color: "#2196f3" },
  { status: "ENTREGUE", label: "ENTREGUE", color: "#16a34a" },
  { status: "AUSENTE", label: "AUSENTE", color: "#ef4444" },
  { status: "DEVOLVIDO", label: "DEVOLVIDO", color: "#6b7280" },
];

const iso = (d: Date) => d.toISOString().slice(0, 10);

const OPERACAO_CSS = `
.operacao-premium{min-height:100vh;background:linear-gradient(135deg,#f8fafc 0%,#eef2f7 52%,#fffdf5 100%);padding:8px 0 40px;color:#17202d}
.operacao-premium .card{border:1px solid #e3e8ef;border-radius:18px;box-shadow:0 12px 30px rgba(25,42,65,.07);background:rgba(255,255,255,.94)}
.operacao-premium button{transition:transform .18s ease,box-shadow .18s ease}
.operacao-premium button:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 16px rgba(25,42,65,.1)}
.operacao-premium .qr-present{background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:16px;box-shadow:0 10px 28px rgba(25,42,65,.1)}
.comprovante-operacao-linha{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));border-bottom:1px solid #edf0f3}
.comprovante-operacao-linha:last-child{border-bottom:0}
.comprovante-operacao-secao{min-width:0;padding:12px 14px;border-right:1px solid #edf0f3}
.comprovante-operacao-secao:last-child{border-right:0}
.comprovante-operacao-titulo{display:flex;align-items:center;gap:7px;margin-bottom:10px;color:#1f2937;font-size:13px;font-weight:900}
.comprovante-operacao-titulo svg{color:#c9a227}
.comprovante-operacao-info{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
.comprovante-operacao-endereco{padding:12px 14px}
.comprovante-operacao-endereco .info-item{margin-top:6px;padding:9px 10px;border:1px solid #e5e7eb;border-radius:9px;background:#f8fafc}
.comprovante-operacao-endereco .info-label{margin-bottom:3px;color:#94a3b8;font-size:10px;font-weight:800}
.comprovante-operacao-endereco .info-valor{color:#1f2937;font-size:12px;font-weight:700;line-height:1.35;word-break:break-word}
.comprovante-operacao-endereco-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
.comprovante-operacao-endereco-completo{grid-column:1/-1}
.comprovante-operacao-endereco-carregando{margin:4px 0 6px;padding:7px 9px;border:1px solid #e5e7eb;border-radius:8px;background:#f8fafc;color:#64748b;font-size:11px}
.comprovante-operacao-mapa{display:inline-flex;align-items:center;gap:5px;margin-top:8px;color:#2563eb;font-size:11px;font-weight:800;text-decoration:none}
.comprovante-operacao-historico{position:relative;display:block;height:122px;overflow:hidden}
.comprovante-operacao-trilha{position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;pointer-events:none}
.comprovante-operacao-historico-item{position:absolute;display:flex;flex-direction:column;align-items:center;gap:3px;padding:0;transform:translateX(-50%);white-space:nowrap;max-width:64px}
.comprovante-operacao-historico-ponto{position:relative;top:auto;left:auto;width:9px;height:9px;border-radius:50%;border:2px solid #fff;flex:0 0 auto;z-index:1}
.comprovante-operacao-historico-status{color:#1f2937;font-size:11px;font-weight:800;line-height:1;text-align:center;white-space:normal}
.comprovante-operacao-historico-data{margin-top:2px;color:#94a3b8;font-size:9px;line-height:1.15;text-align:center;white-space:normal}
.comprovante-operacao-fotos{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
.comprovante-operacao-foto{width:100%;height:130px;object-fit:cover;border:1px solid #e5e7eb;border-radius:8px;background:#f8fafc}
.comprovante-operacao-secao .sem-foto{min-height:92px;padding:10px;font-size:11px}
.operacao-modal-foto{position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;padding:30px;background:rgba(15,23,42,.84)}
.operacao-modal-foto img{max-width:min(1100px,92vw);max-height:88vh;object-fit:contain;border-radius:10px;box-shadow:0 25px 80px rgba(0,0,0,.4)}
.operacao-modal-foto-fechar,.operacao-modal-foto-seta{position:fixed;width:46px;height:46px;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;cursor:pointer}
.operacao-modal-foto-fechar{top:20px;right:22px}
.operacao-modal-foto-seta.esquerda{left:22px}
.operacao-modal-foto-seta.direita{right:22px}
.sla-operacao{color:#0f172a}
.sla-operacao .sla-filtros{border-color:#d9e2ec;background:rgba(255,255,255,.96);box-shadow:0 10px 24px rgba(15,23,42,.07)}
.sla-operacao .sla-filtros label>span{color:#334155!important;letter-spacing:.06em}
.sla-operacao input,.sla-operacao select{box-sizing:border-box;min-height:42px;padding:9px 11px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;color:#0f172a;font-weight:600}
.sla-operacao input:focus,.sla-operacao select:focus{outline:3px solid rgba(37,99,235,.16);border-color:#2563eb}
.sla-operacao .sla-resumo{padding:20px;background:linear-gradient(135deg,#0f2742,#173f63 58%,#1d5272);border:0;color:#fff;box-shadow:0 16px 32px rgba(15,39,66,.18)}
.sla-operacao .sla-resumo-cabecalho{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:16px}
.sla-operacao .sla-resumo-titulo{margin:0;color:#fff;font-size:15px;letter-spacing:.04em}
.sla-operacao .sla-resumo-subtitulo{margin:5px 0 0;color:#b8c9d9;font-size:11px}
.sla-operacao .sla-resumo-indicadores{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
.sla-operacao .sla-indicador{min-width:0;padding:13px 14px;border:1px solid rgba(255,255,255,.13);border-radius:13px;background:rgba(255,255,255,.09)}
.sla-operacao .sla-indicador-label{display:flex;align-items:center;gap:6px;color:#c5d5e3;font-size:10px;font-weight:800;letter-spacing:.06em}
.sla-operacao .sla-indicador-valor{display:block;margin-top:7px;color:#fff;font-size:25px;line-height:1;font-weight:900}
.sla-operacao .sla-indicador.pacotes .sla-indicador-label{color:#8bd1ff}
.sla-operacao .sla-indicador.entregues .sla-indicador-label{color:#8ce5b2}
.sla-operacao .sla-indicador.ausentes .sla-indicador-label{color:#ffacb1}
.sla-operacao .sla-indicador.sla .sla-indicador-label{color:#f6d77e}
.sla-operacao .sla-indicador.produtividade .sla-indicador-label{color:#d5b7ff}
.sla-operacao .sla-subsecao-titulo{margin:20px 0 10px;color:#dce9f4;font-size:10px;letter-spacing:.1em}
.sla-operacao .sla-mercado-geral{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.sla-operacao .sla-mercado-item{padding:11px 13px;border-radius:12px;background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.11)}
.sla-operacao .sla-mercado-item span{display:block;color:#b8c9d9;font-size:10px;font-weight:800}
.sla-operacao .sla-mercado-item strong{display:block;margin-top:5px;color:#fff;font-size:22px}
.sla-operacao .sla-entregadores-titulo{display:flex;align-items:end;justify-content:space-between;gap:12px;margin:22px 2px 10px}
.sla-operacao .sla-entregadores-titulo h2{margin:0;color:#0f172a;font-size:15px;letter-spacing:.04em}
.sla-operacao .sla-entregadores-titulo span{color:#64748b;font-size:11px}
.sla-operacao .sla-cards-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.sla-operacao .sla-score-card{min-width:0;overflow:hidden;border-color:#dbe4ee;box-shadow:0 10px 24px rgba(15,23,42,.07);transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
.sla-operacao .sla-score-card:hover{transform:translateY(-3px);box-shadow:0 16px 30px rgba(15,23,42,.12);border-color:#9bb8d2}
.sla-operacao .sla-score-card.selecionado{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12),0 16px 30px rgba(15,23,42,.12)}
.sla-operacao .sla-score-toggle{min-height:218px;height:100%;padding:17px;display:flex;flex-direction:column;align-items:stretch;justify-content:flex-start;gap:13px}
.sla-operacao .sla-score-cabecalho{display:flex;align-items:center;gap:10px}
.sla-operacao .sla-avatar{display:grid;place-items:center;width:36px;height:36px;flex:0 0 auto;border-radius:11px;background:#e4f2fb;color:#17628a}
.sla-operacao .sla-score-nome{min-width:0;color:#0f172a;font-size:15px;line-height:1.15}
.sla-operacao .sla-score-id{display:block;margin-top:3px;overflow:hidden;color:#94a3b8;font-size:10px;text-overflow:ellipsis;white-space:nowrap}
.sla-operacao .sla-card-metricas{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:auto}
.sla-operacao .sla-card-metrica{padding:9px 10px;border-radius:10px;background:#f8fafc;text-align:left}
.sla-operacao .sla-card-metrica small{display:block;color:#64748b;font-size:9px;font-weight:800;letter-spacing:.04em}
.sla-operacao .sla-card-metrica strong{display:block;margin-top:4px;font-size:18px;line-height:1}
.sla-operacao .sla-card-metrica.pacotes{background:#eff8ff;color:#17628a}
.sla-operacao .sla-card-metrica.entregues{background:#ecfdf3;color:#15803d}
.sla-operacao .sla-card-metrica.ausentes{background:#fff1f2;color:#dc2626}
.sla-operacao .sla-card-metrica.sla{background:#fffbeb;color:#a16207}
.sla-operacao .sla-card-metrica.produtividade{grid-column:1/-1;background:#f5f3ff;color:#6d28d9}
.sla-operacao .sla-card-rodape{display:flex;align-items:center;justify-content:space-between;padding-top:2px;color:#2563eb;font-size:10px;font-weight:900;letter-spacing:.04em}
.sla-operacao .sla-card-rodape span:last-child{font-size:17px;line-height:1}
.sla-operacao .sla-detalhes-painel{margin-top:16px;padding:20px;border-color:#b9d0e5;background:linear-gradient(180deg,#fff,#f8fbfe);box-shadow:0 14px 30px rgba(15,23,42,.09)}
.sla-operacao .sla-detalhes-modal{position:fixed;inset:0;z-index:1000;display:grid;place-items:center;padding:24px;background:rgba(15,23,42,.58);backdrop-filter:blur(4px);overflow:auto}
.sla-operacao .sla-detalhes-modal .sla-detalhes-painel{width:min(980px,100%);max-height:calc(100vh - 48px);margin:0;overflow:auto;box-shadow:0 24px 70px rgba(15,23,42,.28)}
.sla-operacao .sla-detalhes-cabecalho{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}
.sla-operacao .sla-detalhes-cabecalho h2{margin:0;color:#0f172a;font-size:17px}
.sla-operacao .sla-detalhes-cabecalho span{color:#64748b;font-size:11px}
.sla-operacao .sla-detalhes-fechar{display:grid;place-items:center;width:34px;height:34px;flex:0 0 auto;border:1px solid #dbe4ee;border-radius:10px;background:#fff;color:#64748b;cursor:pointer}
.sla-operacao .sla-detalhes-fechar:hover{background:#eff6ff;color:#2563eb}
.sla-operacao .sla-detalhes{display:grid;gap:18px}
.sla-operacao .sla-detalhes-indicadores,.sla-operacao .sla-detalhes-mercado,.sla-operacao .sla-retornos{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}
.sla-operacao .sla-detalhes-mercado{grid-template-columns:repeat(3,minmax(0,1fr))}
.sla-operacao .sla-titulo-secao{margin:0 0 9px;color:#334155;font-size:11px;letter-spacing:.08em}
.sla-operacao .sla-retornos{padding:10px;border:1px solid #dbe4ee;background:#f1f5f9;color:#475569}
.sla-operacao .sla-dia{border:1px solid #dbe4ee;background:#fff;color:#1e293b}
.sla-operacao .sla-historico-cabecalho{display:grid;grid-template-columns:75px repeat(5,minmax(0,1fr));gap:8px;padding:0 10px 6px;color:#94a3b8;font-size:9px;font-weight:900;letter-spacing:.04em}
.sla-operacao .sla-historico-extra{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;padding-top:7px;border-top:1px solid #e5e7eb;color:#64748b;font-size:10px;font-weight:700}
.sla-operacao .sla-vazio{padding:28px;text-align:center;color:#64748b}
@media(max-width:1100px){.sla-operacao .sla-cards-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:850px){.operacao-premium{padding:0 0 28px}.sla-operacao .sla-resumo-indicadores{grid-template-columns:repeat(3,minmax(0,1fr))}.sla-operacao .sla-cards-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:700px){.comprovante-operacao-linha{grid-template-columns:1fr}.comprovante-operacao-secao{border-right:0;border-bottom:1px solid #edf0f3}.comprovante-operacao-secao:last-child{border-bottom:0}.comprovante-operacao-info,.comprovante-operacao-endereco-grid{grid-template-columns:1fr}.sla-operacao .sla-resumo{padding:16px}.sla-operacao .sla-resumo-cabecalho{display:block}.sla-operacao .sla-resumo-indicadores{grid-template-columns:repeat(2,minmax(0,1fr))}.sla-operacao .sla-indicador.produtividade{grid-column:auto}.sla-operacao .sla-mercado-geral,.sla-operacao .sla-detalhes-mercado{grid-template-columns:1fr}.sla-operacao .sla-cards-grid{grid-template-columns:1fr}.sla-operacao .sla-detalhes-indicadores,.sla-operacao .sla-retornos{grid-template-columns:repeat(2,minmax(0,1fr))}.sla-operacao .sla-historico-cabecalho{display:none}.sla-operacao .sla-dia{grid-template-columns:repeat(3,minmax(0,1fr))!important}.sla-operacao .sla-historico-extra{grid-template-columns:1fr}.sla-operacao .sla-detalhes-painel{padding:14px}.sla-operacao .sla-detalhes-modal{padding:10px}.sla-operacao .sla-detalhes-modal .sla-detalhes-painel{max-height:calc(100vh - 20px)}}
@media(max-width:850px){.operacao-premium{padding:0 0 28px}}
`;

function usePermission() {
  const [state, setState] = useState<
    "loading" | "ok" | "denied"
  >("loading");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      async (user) => {
        try {
          if (!user?.email) {
            setState("denied");
            return;
          }

          const email = user.email.trim().toLowerCase();

          const snap = await getDocs(
            query(
              collection(db, "usuarios"),
              where("__name__", "==", email)
            )
          );

          const u = snap.docs[0]?.data();

          setState(
            u?.tipo === "admin" ||
              u?.permissoes?.finalizados === true
              ? "ok"
              : "denied"
          );
        } catch (error) {
          console.error(
            "Erro ao verificar permissão da Operação:",
            error
          );
          setState("denied");
        }
      }
    );

    return () => unsubscribe();
  }, []);

  return state;
}

function usuarioId(p: any) {
  return String(
    p.usuario ||
      p.usuarioFinalizacao ||
      p.usuarioEntrega ||
      p.entregador ||
      p.emailUsuario ||
      p.userEmail ||
      p.usuarioEmail ||
      p.uidUsuario ||
      ""
  )
    .trim()
    .toLowerCase();
}

function nomeUsuario(
  p: any,
  usuariosMap: Record<string, string>
) {
  const id = usuarioId(p);

  const nomeDireto = String(
    p.nomeUsuario ||
      p.nomeEntregador ||
      p.usuarioNome ||
      p.entregadorNome ||
      ""
  ).trim();

  return (
    usuariosMap[id] ||
    nomeDireto ||
    id ||
    "Sem usuário"
  );
}

function codigoPacote(p: any) {
  const raw = p.raw;

  if (raw) {
    if (typeof raw === "object") {
      return String(
        raw.external_grouper_code ||
          raw.codigo ||
          raw.id ||
          p.codigo ||
          p.id ||
          "-"
      );
    }

    if (typeof raw === "string") {
      try {
        const json = JSON.parse(raw);

        return String(
          json.external_grouper_code ||
            json.codigo ||
            json.id ||
            p.codigo ||
            p.id ||
            "-"
        );
      } catch {
        return String(p.codigo || p.id || raw);
      }
    }
  }

  return String(p.codigo || p.id || "-");
}

function valorQr(p: any) {
  if (
    p.raw !== undefined &&
    p.raw !== null &&
    String(p.raw).trim() !== ""
  ) {
    return typeof p.raw === "string"
      ? p.raw
      : JSON.stringify(p.raw);
  }

  return String(p.codigo || p.id || "");
}

function corStatus(status: string) {
  switch (String(status || "").toUpperCase()) {
    case "ENTREGUE":
      return "#16a34a";
    case "AUSENTE":
      return "#ef4444";
    case "ROTA":
      return "#2196f3";
    case "COLETADO":
    case "COLETA":
      return "#c9a227";
    default:
      return "#6b7280";
  }
}

type EnderecoOperacao = {
  rua: string;
  numero: string;
  bairro: string;
  cidade: string;
  estado: string;
  cep: string;
};

function valorOperacao(
  dados: any,
  campos: string[],
  padrao = ""
) {
  for (const campo of campos) {
    const valor = dados?.[campo];

    if (
      valor !== undefined &&
      valor !== null &&
      String(valor).trim() !== ""
    ) {
      return valor;
    }
  }

  return padrao;
}

async function buscarEnderecoOperacao(
  latitude: number,
  longitude: number
): Promise<EnderecoOperacao | null> {
  try {
    const resposta = await fetch(
      "https://nominatim.openstreetmap.org/reverse" +
        `?lat=${encodeURIComponent(latitude)}` +
        `&lon=${encodeURIComponent(longitude)}` +
        "&format=json&addressdetails=1&accept-language=pt-BR",
      { headers: { Accept: "application/json" } }
    );

    if (!resposta.ok) return null;

    const address = (await resposta.json())?.address;
    if (!address) return null;

    return {
      rua:
        address.road ||
        address.pedestrian ||
        address.residential ||
        address.street ||
        "",
      numero: address.house_number || "",
      bairro:
        address.suburb ||
        address.neighbourhood ||
        address.city_district ||
        address.quarter ||
        "",
      cidade:
        address.city ||
        address.town ||
        address.municipality ||
        address.village ||
        "",
      estado: address.state || "",
      cep: address.postcode || "",
    };
  } catch (error) {
    console.error(
      "Erro ao buscar endereço da operação:",
      error
    );
    return null;
  }
}

async function completarEnderecoOperacao(
  dados: any
): Promise<EnderecoOperacao> {
  const endereco: EnderecoOperacao = {
    rua: String(
      valorOperacao(dados, ["rua", "logradouro", "street"])
    ),
    numero: String(
      valorOperacao(dados, ["numero", "number", "house_number"])
    ),
    bairro: String(
      valorOperacao(dados, [
        "bairro",
        "neighborhood",
        "suburb",
      ])
    ),
    cidade: String(
      valorOperacao(dados, [
        "cidade",
        "municipio",
        "city",
      ])
    ),
    estado: String(
      valorOperacao(dados, ["estado", "uf", "state"])
    ),
    cep: String(
      valorOperacao(dados, ["cep", "CEP", "postcode"])
    ),
  };

  const precisaCompletar =
    !endereco.rua ||
    !endereco.numero ||
    !endereco.bairro ||
    !endereco.cidade ||
    !endereco.estado ||
    !endereco.cep;

  if (!precisaCompletar) return endereco;

  const latitude = Number(
    dados?.latitudeEntrega ??
      dados?.latitude ??
      dados?.lat
  );
  const longitude = Number(
    dados?.longitudeEntrega ??
      dados?.longitude ??
      dados?.lng
  );

  if (
    !Number.isFinite(latitude) ||
    !Number.isFinite(longitude)
  ) {
    return endereco;
  }

  const encontrado = await buscarEnderecoOperacao(
    latitude,
    longitude
  );

  if (!encontrado) return endereco;

  return {
    rua: endereco.rua || encontrado.rua,
    numero: endereco.numero || encontrado.numero,
    bairro: endereco.bairro || encontrado.bairro,
    cidade: endereco.cidade || encontrado.cidade,
    estado: endereco.estado || encontrado.estado,
    cep: endereco.cep || encontrado.cep,
  };
}

function corHistoricoOperacao(status: string) {
  switch (
    String(status || "")
      .trim()
      .toUpperCase()
  ) {
    case "COLETADO":
    case "COLETA":
      return "#c9a227";
    case "ROTA":
      return "#2563eb";
    case "AUSENTE":
      return "#ef4444";
    case "ENTREGUE":
    case "DEVOLVIDO":
    case "DEVOLUÇÃO":
    case "DEVOLUCAO":
      return "#16a34a";
    default:
      return "#64748b";
  }
}

function pontoHistoricoOperacao(
  index: number,
  total: number
) {
  const ondulacao = [16, 52, 28, 66, 40, 58];
  const proporcao =
    total > 1 ? index / (total - 1) : 0;

  return {
    x: 46 + proporcao * 268,
    y: ondulacao[index % ondulacao.length],
  };
}

type MovimentoSlaOperacao = {
  data: number;
  status: "COLETADO" | "ROTA" | "ENTREGUE" | "AUSENTE";
  usuario: string;
};

type DiaSlaOperacao = {
  data: number;
  pacotes: number;
  rota: number;
  entregues: number;
  ausentes: number;
  retornos: number;
  retornaramParaRota: number;
  retornosPosteriormenteEntregues: number;
  primeira: number | null;
  ultima: number | null;
  mlAte21: number;
  mlEntre21e23: number;
  mlApos23: number;
};

type SlaOperacao = {
  id: string;
  nome: string;
  dias: Record<string, DiaSlaOperacao>;
};

function dataHistoricoOperacao(valor: any) {
  if (valor?.toDate instanceof Function) {
    const data = valor.toDate();
    return data instanceof Date ? data.getTime() : null;
  }

  const timestamp = timestampMs(valor);
  if (Number.isFinite(timestamp)) return timestamp;

  if (typeof valor === "string") {
    const parsed = Date.parse(valor);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function movimentosSlaOperacao(pacote: any): MovimentoSlaOperacao[] {
  const fonte = pacote?.historico;
  const itens = Array.isArray(fonte)
    ? fonte
    : fonte && typeof fonte === "object"
      ? Object.values(fonte)
      : [];

  return itens
    .filter(
      (item): item is Record<string, any> =>
        Boolean(item) &&
        typeof item === "object" &&
        !Array.isArray(item)
    )
    .map((item) => {
      const data = dataHistoricoOperacao(item.dataHora);
      const status = String(item.status || "")
        .trim()
        .toUpperCase();
      const usuario = String(
        item.usuario ||
          item.entregador ||
          item.motorista ||
          item.responsavel ||
          ""
      )
        .trim()
        .toLowerCase();

      return {
        data,
        status,
        usuario,
      };
    })
    .filter(
      (item): item is MovimentoSlaOperacao =>
        item.data !== null &&
        (item.status === "COLETADO" ||
          item.status === "ROTA" ||
          item.status === "ENTREGUE" ||
          item.status === "AUSENTE")
    )
    .sort((a, b) => a.data - b.data);
}

function chaveDiaSlaOperacao(data: number) {
  const d = new Date(data);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

function inicioDiaSlaOperacao(valor: string) {
  const [ano, mes, dia] = valor.split("-").map(Number);
  return new Date(ano, mes - 1, dia).getTime();
}

function hojeSlaOperacao(offset = 0) {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  hoje.setDate(hoje.getDate() - offset);
  return `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(hoje.getDate()).padStart(2, "0")}`;
}

function horarioSlaOperacao(data: number | null) {
  if (data === null) return "-";
  const d = new Date(data);
  return `${String(d.getHours()).padStart(2, "0")}:${String(
    d.getMinutes()
  ).padStart(2, "0")}`;
}

function dataCurtaSlaOperacao(data: number) {
  const d = new Date(data);
  return `${String(d.getDate()).padStart(2, "0")}/${String(
    d.getMonth() + 1
  ).padStart(2, "0")}`;
}

function isBaixaAutomaticaSlaOperacao(movimento: MovimentoSlaOperacao) {
  const d = new Date(movimento.data);
  const minutos = d.getHours() * 60 + d.getMinutes();
  return (
    (movimento.status === "ENTREGUE" ||
      movimento.status === "AUSENTE") &&
    minutos >= 23 * 60 + 40
  );
}

function isMercadoLivreSlaOperacao(pacote: any) {
  const texto = [
    pacote?.empresa,
    pacote?.tipo,
    pacote?.transportadora,
    pacote?.origem,
  ]
    .filter(Boolean)
    .join(" ")
    .toUpperCase()
    .replace(/\s+/g, " ");

  return (
    texto.includes("MERCADO LIVRE") ||
    texto.includes("MERCADOLIVRE") ||
    texto.includes("MELI")
  );
}

function formatarPercentualSlaOperacao(valor: number) {
  return `${valor.toFixed(1).replace(".", ",")}%`;
}

function valorProdutividadeSlaOperacao(
  primeira: number | null,
  ultima: number | null,
  finalizados: number
) {
  if (primeira === null || ultima === null || finalizados === 0) {
    return "-";
  }

  const horas = (ultima - primeira) / 3600000;
  return horas <= 0
    ? "-"
    : `${Math.round(finalizados / horas)}/h`;
}

function SlaOperacao({
  items,
  usuariosMap,
}: {
  items: any[];
  usuariosMap: Record<string, string>;
}) {
  const [periodo, setPeriodo] = useState("7");
  const [ini, setIni] = useState(hojeSlaOperacao(6));
  const [fim, setFim] = useState(hojeSlaOperacao());
  const [usuarioFiltro, setUsuarioFiltro] = useState("TODOS");
  const [busca, setBusca] = useState("");
  const [selecionadoId, setSelecionadoId] = useState<string | null>(null);

  const dados = useMemo(() => {
    const mapa = new Map<string, SlaOperacao>();

    const obter = (id: string) => {
      if (!mapa.has(id)) {
        mapa.set(id, {
          id,
          nome: usuariosMap[id] || id || "Sem usuário",
          dias: {},
        });
      }
      return mapa.get(id)!;
    };

    items.forEach((pacote) => {
      const movimentos = movimentosSlaOperacao(pacote);
      if (!movimentos.length) return;

      const idPacote = usuarioId(pacote);
      const id =
        idPacote ||
        movimentos.find((movimento) => movimento.usuario)?.usuario ||
        "";
      if (!id) return;

      const porDia = new Map<string, MovimentoSlaOperacao[]>();
      movimentos.forEach((movimento) => {
        const chave = chaveDiaSlaOperacao(movimento.data);
        const lista = porDia.get(chave) || [];
        lista.push(movimento);
        porDia.set(chave, lista);
      });

      const score = obter(id);
      porDia.forEach((movimentosDoDia, chave) => {
        const rotas = movimentosDoDia.filter(
          (movimento) => movimento.status === "ROTA"
        );
        const baixas = movimentosDoDia.filter(
          (movimento) =>
            movimento.status === "ENTREGUE" ||
            movimento.status === "AUSENTE"
        );

        // COLETADO sozinho não cria um registro de SLA.
        if (!rotas.length && !baixas.length) return;

        const dia =
          score.dias[chave] ||
          (score.dias[chave] = {
            data: inicioDiaSlaOperacao(chave),
            pacotes: 0,
            rota: 0,
            entregues: 0,
            ausentes: 0,
            retornos: 0,
            retornaramParaRota: 0,
            retornosPosteriormenteEntregues: 0,
            primeira: null,
            ultima: null,
            mlAte21: 0,
            mlEntre21e23: 0,
            mlApos23: 0,
          });

        dia.pacotes++;

        const dataAnterior = new Date(inicioDiaSlaOperacao(chave));
        dataAnterior.setDate(dataAnterior.getDate() - 1);
        const chaveDiaAnterior = chaveDiaSlaOperacao(
          dataAnterior.getTime()
        );
        const ausenteNoDiaAnterior = movimentos.some(
          (movimento) =>
            chaveDiaSlaOperacao(movimento.data) === chaveDiaAnterior &&
            movimento.status === "AUSENTE"
        );
        const teveEntregueHoje = movimentosDoDia.some(
          (movimento) => movimento.status === "ENTREGUE"
        );

        // TOTAL: AUSENTE no dia anterior e uma nova movimentação de ROTA ou
        // ENTREGUE no dia atual. Conta uma vez por código/dia.
        if (
          ausenteNoDiaAnterior &&
          (rotas.length > 0 || teveEntregueHoje)
        ) {
          dia.retornos++;
        }

        if (rotas.length) {
          dia.rota++;
          dia.primeira =
            dia.primeira === null
              ? rotas[0].data
              : Math.min(dia.primeira, rotas[0].data);

          // VOLTARAM À ROTA: AUSENTE no dia anterior e ROTA no dia atual.
          if (ausenteNoDiaAnterior) {
            dia.retornaramParaRota++;
          }
        }

        // POST. ENTREGUES: AUSENTE no dia anterior e ENTREGUE em qualquer
        // momento do dia atual, com ou sem passagem por ROTA.
        if (ausenteNoDiaAnterior && teveEntregueHoje) {
          dia.retornosPosteriormenteEntregues++;
        }

        const ultimaBaixa = baixas[baixas.length - 1];
        if (ultimaBaixa?.status === "ENTREGUE") {
          dia.entregues++;
        } else if (ultimaBaixa?.status === "AUSENTE") {
          dia.ausentes++;
        }

        // Baixas automáticas a partir de 23:40 permanecem no histórico e
        // continuam participando dos demais cálculos, mas não definem a
        // última baixa real do entregador.
        const baixasParaUltima = baixas.filter(
          (movimento) => !isBaixaAutomaticaSlaOperacao(movimento)
        );
        if (baixasParaUltima.length) {
          const ultimaHumana =
            baixasParaUltima[baixasParaUltima.length - 1].data;
          dia.ultima =
            dia.ultima === null
              ? ultimaHumana
              : Math.max(dia.ultima, ultimaHumana);
        }

        if (isMercadoLivreSlaOperacao(pacote)) {
          const entregas = movimentosDoDia.filter(
            (movimento) => movimento.status === "ENTREGUE"
          );
          const ultimaEntrega = entregas[entregas.length - 1];
          if (ultimaEntrega) {
            const d = new Date(ultimaEntrega.data);
            const minutos = d.getHours() * 60 + d.getMinutes();
            if (minutos <= 21 * 60) dia.mlAte21++;
            else if (minutos <= 23 * 60) dia.mlEntre21e23++;
            else dia.mlApos23++;
          }
        }
      });
    });

    return Array.from(mapa.values());
  }, [items, usuariosMap]);

  const usuarios = useMemo(() => {
    const ids = new Set<string>(Object.keys(usuariosMap));
    dados.forEach((item) => ids.add(item.id));
    return Array.from(ids)
      .filter(Boolean)
      .map((id) => ({ id, nome: usuariosMap[id] || id }))
      .sort((a, b) => a.nome.localeCompare(b.nome));
  }, [dados, usuariosMap]);

  const cards = useMemo(() => {
    const inicio = inicioDiaSlaOperacao(ini);
    const fimData = inicioDiaSlaOperacao(fim) + 86400000 - 1;
    const buscaNormal = busca.trim().toLowerCase();

    return dados
      .filter((score) => {
        if (
          usuarioFiltro !== "TODOS" &&
          score.id !== usuarioFiltro
        ) {
          return false;
        }
        return !buscaNormal || score.nome.toLowerCase().includes(buscaNormal);
      })
      .map((score) => {
        const dias = Object.values(score.dias)
          .filter((dia) => dia.data >= inicio && dia.data <= fimData)
          .sort((a, b) => b.data - a.data);
        const total = dias.reduce((sum, dia) => sum + dia.pacotes, 0);
        const rota = dias.reduce((sum, dia) => sum + dia.rota, 0);
        const entregues = dias.reduce(
          (sum, dia) => sum + dia.entregues,
          0
        );
        const ausentes = dias.reduce(
          (sum, dia) => sum + dia.ausentes,
          0
        );
        const retornos = dias.reduce(
          (sum, dia) => sum + dia.retornos,
          0
        );
        const retornaramParaRota = dias.reduce(
          (sum, dia) => sum + dia.retornaramParaRota,
          0
        );
        const retornosPosteriormenteEntregues = dias.reduce(
          (sum, dia) => sum + dia.retornosPosteriormenteEntregues,
          0
        );
        const primeiras = dias
          .map((dia) => dia.primeira)
          .filter((valor): valor is number => valor !== null);
        const ultimas = dias
          .map((dia) => dia.ultima)
          .filter((valor): valor is number => valor !== null);
        const mlAte21 = dias.reduce(
          (sum, dia) => sum + dia.mlAte21,
          0
        );
        const mlEntre21e23 = dias.reduce(
          (sum, dia) => sum + dia.mlEntre21e23,
          0
        );
        const mlApos23 = dias.reduce(
          (sum, dia) => sum + dia.mlApos23,
          0
        );

        return {
          ...score,
          dias,
          total,
          rota,
          entregues,
          ausentes,
          retornos,
          retornaramParaRota,
          retornosPosteriormenteEntregues,
          primeira: primeiras.length ? Math.min(...primeiras) : null,
          ultima: ultimas.length ? Math.max(...ultimas) : null,
          mlAte21,
          mlEntre21e23,
          mlApos23,
        };
      })
      .filter((score) => score.total > 0)
      .sort((a, b) => b.total - a.total);
  }, [dados, fim, ini, busca, usuarioFiltro]);

  const resumo = useMemo(() => {
    const total = cards.reduce((sum, score) => sum + score.total, 0);
    const entregues = cards.reduce((sum, score) => sum + score.entregues, 0);
    const ausentes = cards.reduce((sum, score) => sum + score.ausentes, 0);
    const finalizados = entregues + ausentes;
    const primeiras = cards
      .map((score) => score.primeira)
      .filter((valor): valor is number => valor !== null);
    const ultimas = cards
      .map((score) => score.ultima)
      .filter((valor): valor is number => valor !== null);

    return {
      total,
      entregues,
      ausentes,
      sla: finalizados ? (entregues / finalizados) * 100 : 0,
      produtividade: valorProdutividadeSlaOperacao(
        primeiras.length ? Math.min(...primeiras) : null,
        ultimas.length ? Math.max(...ultimas) : null,
        finalizados
      ),
      mlAte21: cards.reduce((sum, score) => sum + score.mlAte21, 0),
      mlEntre21e23: cards.reduce(
        (sum, score) => sum + score.mlEntre21e23,
        0
      ),
      mlApos23: cards.reduce((sum, score) => sum + score.mlApos23, 0),
    };
  }, [cards]);

  // Salva o resultado diário do SLA (já calculado acima) na coleção sla_operacao.
  useEffect(() => {
    if (!cards.length) return;
    const gravacoes: Promise<void>[] = [];
    cards.forEach((score) => {
      score.dias.forEach((dia) => {
        const data = chaveDiaSlaOperacao(dia.data);
        const finalizados = dia.entregues + dia.ausentes;
        gravacoes.push(
          setDoc(
            doc(db, "sla_operacao", `${score.id}_${data}`),
            {
              usuarioId: score.id,
              usuarioNome: score.nome,
              data,
              pacotes: dia.pacotes,
              rota: dia.rota,
              entregues: dia.entregues,
              ausentes: dia.ausentes,
              retornos: dia.retornos,
              retornaramParaRota: dia.retornaramParaRota,
              retornosPosteriormenteEntregues: dia.retornosPosteriormenteEntregues,
              primeira: dia.primeira,
              ultima: dia.ultima,
              mlAte21: dia.mlAte21,
              mlEntre21e23: dia.mlEntre21e23,
              mlApos23: dia.mlApos23,
              sla: finalizados ? (dia.entregues / finalizados) * 100 : 0,
              produtividade: valorProdutividadeSlaOperacao(
                dia.primeira,
                dia.ultima,
                finalizados
              ),
              atualizadoEm: serverTimestamp(),
            },
            { merge: true }
          )
        );
      });
    });
    Promise.all(gravacoes).catch((erro) =>
      console.error("Erro ao salvar sla_operacao:", erro)
    );
  }, [cards]);

  const selecionado = selecionadoId
    ? cards.find((score) => score.id === selecionadoId) || null
    : null;

  function selecionarPeriodo(valor: string) {
    setPeriodo(valor);
    const hoje = hojeSlaOperacao();
    if (valor === "hoje") {
      setIni(hoje);
      setFim(hoje);
    } else if (valor === "ontem") {
      const ontem = hojeSlaOperacao(1);
      setIni(ontem);
      setFim(ontem);
    } else if (valor === "7") {
      setIni(hojeSlaOperacao(6));
      setFim(hoje);
    } else if (valor === "30") {
      setIni(hojeSlaOperacao(29));
      setFim(hoje);
    }
  }

  return (
    <section className="sla-operacao">
      <div className="card sla-filtros" style={{ padding: 16, marginBottom: 16, display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 12 }}>
        <label>
          <span style={labelStyle}>PERÍODO</span>
          <select value={periodo} onChange={(event) => selecionarPeriodo(event.target.value)} style={{ width: "100%" }}>
            <option value="hoje">Hoje</option>
            <option value="ontem">Ontem</option>
            <option value="7">Últimos 7 dias</option>
            <option value="30">Últimos 30 dias</option>
            <option value="personalizado">Período personalizado</option>
          </select>
        </label>
        <label>
          <span style={labelStyle}>DE</span>
          <input type="date" value={ini} onChange={(event) => { setPeriodo("personalizado"); setIni(event.target.value); }} style={{ width: "100%" }} />
        </label>
        <label>
          <span style={labelStyle}>ATÉ</span>
          <input type="date" value={fim} onChange={(event) => { setPeriodo("personalizado"); setFim(event.target.value); }} style={{ width: "100%" }} />
        </label>
        <label>
          <span style={labelStyle}>ENTREGADOR</span>
          <select value={usuarioFiltro} onChange={(event) => setUsuarioFiltro(event.target.value)} style={{ width: "100%" }}>
            <option value="TODOS">Todos</option>
            {usuarios.map((usuario) => <option key={usuario.id} value={usuario.id}>{usuario.nome}</option>)}
          </select>
        </label>
        <label>
          <span style={labelStyle}>BUSCA</span>
          <input value={busca} onChange={(event) => setBusca(event.target.value)} placeholder="Nome do entregador" style={{ width: "100%" }} />
        </label>
      </div>

      {!cards.length ? (
        <div className="card sla-vazio">Nenhum entregador com histórico no período selecionado.</div>
      ) : (
        <>
          <section className="card sla-resumo">
            <div className="sla-resumo-cabecalho">
              <div>
                <h2 className="sla-resumo-titulo">RESUMO GERAL DO PERÍODO</h2>
                <p className="sla-resumo-subtitulo">{cards.length} entregador(es) no filtro atual</p>
              </div>
            </div>
            <div className="sla-resumo-indicadores">
              <div className="sla-indicador pacotes"><span className="sla-indicador-label">PACOTES</span><strong className="sla-indicador-valor">{resumo.total}</strong></div>
              <div className="sla-indicador entregues"><span className="sla-indicador-label">ENTREGUES</span><strong className="sla-indicador-valor">{resumo.entregues}</strong></div>
              <div className="sla-indicador ausentes"><span className="sla-indicador-label">AUSENTES</span><strong className="sla-indicador-valor">{resumo.ausentes}</strong></div>
              <div className="sla-indicador sla"><span className="sla-indicador-label">SLA</span><strong className="sla-indicador-valor">{formatarPercentualSlaOperacao(resumo.sla)}</strong></div>
              <div className="sla-indicador produtividade"><span className="sla-indicador-label">PRODUTIVIDADE MÉDIA</span><strong className="sla-indicador-valor">{resumo.produtividade}</strong></div>
            </div>
            <h3 className="sla-subsecao-titulo">MERCADO LIVRE · CUMPRIMENTO DO PRAZO</h3>
            <div className="sla-mercado-geral">
              <div className="sla-mercado-item"><span>ATÉ 21:00</span><strong>{resumo.mlAte21}</strong></div>
              <div className="sla-mercado-item"><span>21:01–23:00</span><strong>{resumo.mlEntre21e23}</strong></div>
              <div className="sla-mercado-item"><span>APÓS 23:00</span><strong>{resumo.mlApos23}</strong></div>
            </div>
          </section>

          <div className="sla-entregadores-titulo">
            <h2>ENTREGADORES</h2>
            <span>Selecione um card para ver os detalhes</span>
          </div>
          <div className="sla-cards-grid">
            {cards.map((score) => {
              const finalizados = score.entregues + score.ausentes;
              const taxa = finalizados ? (score.entregues / finalizados) * 100 : 0;
              const selecionadoAtual = selecionadoId === score.id;
              return (
                <article className={`card sla-score-card${selecionadoAtual ? " selecionado" : ""}`} key={score.id}>
                  <button
                    type="button"
                    aria-pressed={selecionadoAtual}
                    onClick={() => setSelecionadoId(selecionadoAtual ? null : score.id)}
                    className="sla-score-toggle"
                    style={{ width: "100%", border: 0, background: "transparent", color: "#111827", cursor: "pointer", textAlign: "left" }}
                  >
                    <div className="sla-score-cabecalho">
                      <span className="sla-avatar"><User size={18} /></span>
                      <div style={{ minWidth: 0 }}>
                        <strong className="sla-score-nome">{score.nome}</strong>
                        <small className="sla-score-id">{score.id}</small>
                      </div>
                    </div>
                    <div className="sla-card-metricas">
                      <div className="sla-card-metrica pacotes"><small>PACOTES</small><strong>{score.total}</strong></div>
                      <div className="sla-card-metrica entregues"><small>ENTREGUES</small><strong>{score.entregues}</strong></div>
                      <div className="sla-card-metrica ausentes"><small>AUSENTES</small><strong>{score.ausentes}</strong></div>
                      <div className="sla-card-metrica sla"><small>SLA</small><strong>{formatarPercentualSlaOperacao(taxa)}</strong></div>
                      <div className="sla-card-metrica produtividade"><small>PRODUTIVIDADE</small><strong>{valorProdutividadeSlaOperacao(score.primeira, score.ultima, finalizados)}</strong></div>
                    </div>
                    <div className="sla-card-rodape"><span>{selecionadoAtual ? "OCULTAR DETALHES" : "VER DETALHES"}</span><span>{selecionadoAtual ? "−" : "+"}</span></div>
                  </button>
                </article>
              );
            })}
          </div>

          {selecionado && (
            <div
              className="sla-detalhes-modal"
              role="dialog"
              aria-modal="true"
              aria-label={`Detalhes de ${selecionado.nome}`}
              onClick={(event) => {
                if (event.target === event.currentTarget) {
                  setSelecionadoId(null);
                }
              }}
            >
              <section className="card sla-detalhes-painel">
              <div className="sla-detalhes-cabecalho">
                <div>
                  <h2>DETALHES DE {selecionado.nome}</h2>
                  <span>{selecionado.id}</span>
                </div>
                 <button
                   type="button"
                   className="sla-detalhes-fechar"
                   aria-label="Fechar detalhes"
                   onClick={() => setSelecionadoId(null)}
                 >
                   <X size={18} />
                 </button>
              </div>
              <div className="sla-detalhes">
                <div className="sla-detalhes-indicadores">
                  <SlaInfo label="ROTA" valor={String(selecionado.rota)} />
                  <SlaInfo label="PRIMEIRA MOVIMENTAÇÃO" valor={horarioSlaOperacao(selecionado.primeira)} />
                  <SlaInfo label="ÚLTIMA BAIXA" valor={horarioSlaOperacao(selecionado.ultima)} />
                  <SlaInfo label="PRODUTIVIDADE" valor={valorProdutividadeSlaOperacao(selecionado.primeira, selecionado.ultima, selecionado.entregues + selecionado.ausentes)} />
                </div>

                <div>
                  <h3 className="sla-titulo-secao">MERCADO LIVRE · CUMPRIMENTO DO PRAZO</h3>
                  <div className="sla-detalhes-mercado">
                    <SlaInfo label="ATÉ 21:00" valor={String(selecionado.mlAte21)} />
                    <SlaInfo label="21:01–23:00" valor={String(selecionado.mlEntre21e23)} />
                    <SlaInfo label="APÓS 23:00" valor={String(selecionado.mlApos23)} />
                  </div>
                </div>

                <div>
                  <h3 className="sla-titulo-secao">RETORNOS</h3>
                  <div className="sla-retornos">
                    <SlaInfo label="TOTAL" valor={String(selecionado.retornos)} />
                    <SlaInfo label="VOLTARAM À ROTA" valor={String(selecionado.retornaramParaRota)} />
                    <SlaInfo label="POST. ENTREGUES" valor={String(selecionado.retornosPosteriormenteEntregues)} />
                  </div>
                </div>

                <div>
                  <h3 className="sla-titulo-secao">HISTÓRICO DIÁRIO</h3>
                  <div className="sla-historico-cabecalho"><span>DATA</span><span>PACOTES</span><span>ROTA</span><span>ENTREGUES</span><span>AUSENTES</span><span>SLA</span></div>
                  <div style={{ display: "grid", gap: 8 }}>
                    {selecionado.dias.map((dia) => {
                      const diaFinalizados = dia.entregues + dia.ausentes;
                      const diaTaxa = diaFinalizados ? (dia.entregues / diaFinalizados) * 100 : 0;
                      return (
                        <div key={dia.data} className="sla-dia" style={{ display: "grid", gridTemplateColumns: "75px repeat(5,minmax(0,1fr))", gap: 8, alignItems: "center", padding: 10, borderRadius: 11, fontSize: 11 }}>
                          <strong>{dataCurtaSlaOperacao(dia.data)}</strong>
                          <span>P {dia.pacotes}</span>
                          <span style={{ color: "#2563eb" }}>R {dia.rota}</span>
                          <span style={{ color: "#16a34a" }}>✓ {dia.entregues}</span>
                          <span style={{ color: "#dc2626" }}>! {dia.ausentes}</span>
                          <span>{formatarPercentualSlaOperacao(diaTaxa)}</span>
                          <div className="sla-historico-extra">
                            <span>RETORNOS {dia.retornos}</span>
                            <span>VOLTARAM À ROTA {dia.retornaramParaRota}</span>
                            <span>POST. ENTREGUES {dia.retornosPosteriormenteEntregues}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              </section>
            </div>
          )}
        </>
      )}
    </section>
  );
}

function SlaInfo({ label, valor }: { label: string; valor: string }) {
  return (
    <div
      style={{
        padding: 10,
        border: "1px solid #cbd5e1",
        borderRadius: 8,
        background: "#fff",
        color: "#0f172a",
      }}
    >
      <small style={{ display: "block", color: "#475569", fontWeight: 800 }}>
        {label}
      </small>
      <strong style={{ display: "block", marginTop: 4 }}>{valor}</strong>
    </div>
  );
}

export default function Operacao() {
  const permission = usePermission();

  const [items, setItems] = useState<any[]>([]);
  const [usuariosMap, setUsuariosMap] = useState<
    Record<string, string>
  >({});
  const [loading, setLoading] = useState(true);

  const [ini, setIni] = useState(
    iso(new Date(Date.now() - 86400000))
  );
  const [fim, setFim] = useState(
    iso(new Date(Date.now() - 86400000))
  );

  const [busca, setBusca] = useState("");
  const [empresa, setEmpresa] = useState("TODAS");
  const [usuarioFiltro, setUsuarioFiltro] =
    useState("TODOS");
  const [tipoFiltro, setTipoFiltro] = useState("TODOS");
  const [confirmacaoFiltro, setConfirmacaoFiltro] =
    useState<
      "TODOS" | "CONFIRMADOS" | "NAO_CONFIRMADOS"
    >("TODOS");
  const [statusFiltros, setStatusFiltros] =
    useState<StatusPacote[]>([]);
  const [filtrosAberto, setFiltrosAberto] =
    useState(true);

  const [visualizacao, setVisualizacao] =
    useState<Visualizacao>("QR");

  const [indiceQr, setIndiceQr] = useState(0);
  const [salvando, setSalvando] =
    useState<string | null>(null);
  const [pacoteComprovante, setPacoteComprovante] =
    useState<any | null>(null);

  useEffect(() => {
    let cancelarPacotes: (() => void) | undefined;
    let cancelarUsuarios: (() => void) | undefined;

    async function iniciar() {
      try {
        const iniciais = await listarPacotes();
        setItems(iniciais as any[]);

        cancelarPacotes = onSnapshot(
          collection(db, "controle_codigos"),
          (snap) => {
            const lista = snap.docs.map((d) => ({
              id: d.id,
              ...d.data(),
            }));

            setItems(lista);
            setLoading(false);
          },
          (erro) => {
            console.error(erro);
            setLoading(false);
          }
        );

        cancelarUsuarios = onSnapshot(
          collection(db, "usuarios"),
          (snap) => {
            const mapa: Record<string, string> = {};

            snap.docs.forEach((d) => {
              const u: any = d.data();

              const nome = String(
                u.nome ||
                  u.name ||
                  u.nomeCompleto ||
                  ""
              ).trim();

              const email = String(u.email || "")
                .trim()
                .toLowerCase();

              const id = String(d.id || "")
                .trim()
                .toLowerCase();

              if (email && nome) mapa[email] = nome;
              if (id && nome) mapa[id] = nome;
            });

            setUsuariosMap(mapa);
          }
        );
      } catch (erro) {
        console.error(erro);
        setLoading(false);
      }
    }

    iniciar();

    return () => {
      cancelarPacotes?.();
      cancelarUsuarios?.();
    };
  }, []);

  const empresas = useMemo(() => {
    return Array.from(
      new Set(
        items
          .map((p) =>
            String(p.empresa || "").trim()
          )
          .filter(Boolean)
      )
    ).sort();
  }, [items]);

  const usuarios = useMemo(() => {
    const mapa = new Map<string, string>();

    items.forEach((p) => {
      const id = usuarioId(p);

      if (!id) return;

      mapa.set(
        id,
        nomeUsuario(p, usuariosMap)
      );
    });

    return Array.from(mapa.entries())
      .map(([id, nome]) => ({ id, nome }))
      .sort((a, b) =>
        a.nome.localeCompare(b.nome)
      );
  }, [items, usuariosMap]);

  const tipos = useMemo(() => {
    return Array.from(
      new Set(
        items
          .map((p) =>
            String(p.tipo || "").trim()
          )
          .filter(Boolean)
      )
    ).sort();
  }, [items]);

  const base = useMemo(() => {
    const buscaNormal = busca.trim().toLowerCase();

    const inicio = new Date(
      `${ini}T00:00:00`
    ).getTime();

    const fimData = new Date(
      `${fim}T23:59:59.999`
    ).getTime();

    return items.filter((p) => {
      const data = timestampMs(
        p.dataHoraBaixa ||
          p.dataHora ||
          p.data ||
          p.createdAt
      );

      if (
        Number.isFinite(data) &&
        (data < inicio || data > fimData)
      ) {
        return false;
      }

      if (
        empresa !== "TODAS" &&
        String(p.empresa || "") !== empresa
      ) {
        return false;
      }

      const idUsuario = usuarioId(p);

      if (
        usuarioFiltro !== "TODOS" &&
        idUsuario !== usuarioFiltro
      ) {
        return false;
      }

      if (
        tipoFiltro !== "TODOS" &&
        String(p.tipo || "") !== tipoFiltro
      ) {
        return false;
      }

      if (
        statusFiltros.length > 0 &&
        !statusFiltros.includes(p.status)
      ) {
        return false;
      }

      if (buscaNormal) {
        const texto = [
          codigoPacote(p),
          p.empresa,
          p.status,
          p.tipo,
          usuarioId(p),
          nomeUsuario(p, usuariosMap),
        ]
          .join(" ")
          .toLowerCase();

        if (!texto.includes(buscaNormal)) {
          return false;
        }
      }

      return true;
    });
  }, [
    items,
    ini,
    fim,
    busca,
    empresa,
    usuarioFiltro,
    tipoFiltro,
    statusFiltros,
    usuariosMap,
  ]);

  const baseQr = useMemo(() => {
    if (confirmacaoFiltro === "TODOS") {
      return base;
    }

    return base.filter((p) =>
      confirmacaoFiltro === "CONFIRMADOS"
        ? p.confirmado === true
        : p.confirmado !== true
    );
  }, [base, confirmacaoFiltro]);

  const resumoUsuarios = useMemo(() => {
    const mapa = new Map<
      string,
      {
        id: string;
        nome: string;
        total: number;
        entregue: number;
        ausente: number;
        rota: number;
        coletado: number;
        devolvido: number;
      }
    >();

    base.forEach((p) => {
      const id =
        usuarioId(p) || "__sem_usuario__";

      if (!mapa.has(id)) {
        mapa.set(id, {
          id,
          nome:
            id === "__sem_usuario__"
              ? "Sem usuário"
              : nomeUsuario(p, usuariosMap),
          total: 0,
          entregue: 0,
          ausente: 0,
          rota: 0,
          coletado: 0,
          devolvido: 0,
        });
      }

      const atual = mapa.get(id)!;

      atual.total++;

      switch (p.status) {
        case "ENTREGUE":
          atual.entregue++;
          break;
        case "AUSENTE":
          atual.ausente++;
          break;
        case "ROTA":
          atual.rota++;
          break;
        case "COLETADO":
          atual.coletado++;
          break;
        case "DEVOLVIDO":
          atual.devolvido++;
          break;
      }
    });

    return Array.from(mapa.values()).sort(
      (a, b) => b.total - a.total
    );
  }, [base, usuariosMap]);

  const pacoteQr = baseQr[indiceQr];

  function toggleStatus(status: StatusPacote) {
    setStatusFiltros((atual) =>
      atual.includes(status)
        ? atual.filter((s) => s !== status)
        : [...atual, status]
    );

    setIndiceQr(0);
  }

  function limparFiltros() {
    setBusca("");
    setEmpresa("TODAS");
    setUsuarioFiltro("TODOS");
    setTipoFiltro("TODOS");
    setConfirmacaoFiltro("TODOS");
    setStatusFiltros([]);
    setIndiceQr(0);
  }

  async function marcarPacote(p: any) {
    if (
      p.status !== "ENTREGUE" &&
      p.status !== "AUSENTE"
    ) {
      return;
    }

    const id = String(
      p.id || p.codigo || ""
    ).trim();

    if (!id) {
      alert("Código do pacote não encontrado.");
      return;
    }

    try {
      setSalvando(id);

      await updateDoc(
        doc(db, "controle_codigos", id),
        {
          confirmado: p.confirmado !== true,
        }
      );
    } catch (erro) {
      console.error(
        "Erro ao marcar pacote:",
        erro
      );

      alert(
        "Não foi possível salvar a marcação. Verifique se o documento existe em controle_codigos."
      );
    } finally {
      setSalvando(null);
    }
  }

  useEffect(() => {
    if (visualizacao !== "QR") return;

    function teclado(e: KeyboardEvent) {
      const tag =
        (e.target as HTMLElement)?.tagName;

      if (
        tag === "INPUT" ||
        tag === "TEXTAREA" ||
        tag === "SELECT"
      ) {
        return;
      }

      if (
        e.key === "ArrowLeft" ||
        e.key === "ArrowUp"
      ) {
        e.preventDefault();

        setIndiceQr((i) =>
          Math.max(0, i - 1)
        );
      }

      if (
        e.key === "ArrowRight" ||
        e.key === "ArrowDown"
      ) {
        e.preventDefault();

        setIndiceQr((i) =>
          Math.min(
            baseQr.length - 1,
            i + 1
          )
        );
      }
    }

    window.addEventListener(
      "keydown",
      teclado
    );

    return () =>
      window.removeEventListener(
        "keydown",
        teclado
      );
  }, [visualizacao, baseQr.length]);

  if (permission === "loading") {
    return (
      <div
        style={{
          minHeight: 300,
          display: "grid",
          placeItems: "center",
          color: "#64748b",
          fontWeight: 700,
        }}
      >
        Verificando permissão...
      </div>
    );
  }

  if (permission === "denied") {
    return (
      <div
        style={{
          minHeight: 300,
          display: "grid",
          placeItems: "center",
        }}
      >
        <div
          style={{
            textAlign: "center",
            padding: 30,
            background: "#fff",
            border: "1px solid #fecaca",
            borderRadius: 16,
            color: "#991b1b",
          }}
        >
          <AlertTriangle
            size={32}
            style={{ marginBottom: 10 }}
          />

          <div style={{ fontWeight: 800 }}>
            Acesso não permitido
          </div>

          <div
            style={{
              marginTop: 6,
              fontSize: 13,
            }}
          >
            Você não tem permissão para acessar Operação.
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{OPERACAO_CSS}</style>

      <div className="operacao-premium">
        <PageHeader
          title="Operação"
          subtitle="Controle operacional dos pacotes."
        />

        {visualizacao !== "SLA" && (
          <div
            className="card"
            style={{
              padding: 16,
              marginBottom: 16,
            }}
          >
          <div
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <div
              style={{
                flex: "1 1 280px",
                display: "flex",
                alignItems: "center",
                gap: 8,
                border: "1px solid #d1d5db",
                borderRadius: 9,
                padding: "0 12px",
              }}
            >
              <Search size={18} />

              <input
                value={busca}
                onChange={(e) => {
                  setBusca(e.target.value);
                  setIndiceQr(0);
                }}
                placeholder="Buscar código, empresa, usuário..."
                style={{
                  border: 0,
                  outline: 0,
                  width: "100%",
                  padding: "12px 0",
                }}
              />
            </div>

            <button
              onClick={() =>
                setFiltrosAberto((v) => !v)
              }
              style={botao}
            >
              <SlidersHorizontal size={17} />
              FILTROS
            </button>

            <button
              onClick={limparFiltros}
              style={botao}
            >
              LIMPAR
            </button>
          </div>

          {filtrosAberto && (
            <div
              style={{
                marginTop: 16,
                paddingTop: 16,
                borderTop: "1px solid #e5e7eb",
              }}
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(auto-fit,minmax(180px,1fr))",
                  gap: 12,
                }}
              >
                <label>
                  <span style={labelStyle}>
                    DE
                  </span>

                  <input
                    type="date"
                    value={ini}
                    onChange={(e) => {
                      setIni(e.target.value);
                      setIndiceQr(0);
                    }}
                    style={{ width: "100%" }}
                  />
                </label>

                <label>
                  <span style={labelStyle}>
                    ATÉ
                  </span>

                  <input
                    type="date"
                    value={fim}
                    onChange={(e) => {
                      setFim(e.target.value);
                      setIndiceQr(0);
                    }}
                    style={{ width: "100%" }}
                  />
                </label>

                <label>
                  <span style={labelStyle}>
                    EMPRESA
                  </span>

                  <select
                    value={empresa}
                    onChange={(e) => {
                      setEmpresa(e.target.value);
                      setIndiceQr(0);
                    }}
                    style={{ width: "100%" }}
                  >
                    <option value="TODAS">
                      Todas
                    </option>

                    {empresas.map((item) => (
                      <option
                        key={item}
                        value={item}
                      >
                        {item}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <span style={labelStyle}>
                    USUÁRIO
                  </span>

                  <select
                    value={usuarioFiltro}
                    onChange={(e) => {
                      setUsuarioFiltro(
                        e.target.value
                      );
                      setIndiceQr(0);
                    }}
                    style={{ width: "100%" }}
                  >
                    <option value="TODOS">
                      Todos
                    </option>

                    {usuarios.map((item) => (
                      <option
                        key={item.id}
                        value={item.id}
                      >
                        {item.nome}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <span style={labelStyle}>
                    TIPO
                  </span>

                  <select
                    value={tipoFiltro}
                    onChange={(e) => {
                      setTipoFiltro(
                        e.target.value
                      );
                      setIndiceQr(0);
                    }}
                    style={{ width: "100%" }}
                  >
                    <option value="TODOS">
                      Todos
                    </option>

                    {tipos.map((item) => (
                      <option
                        key={item}
                        value={item}
                      >
                        {nomeTipo(item)}
                      </option>
                    ))}
                  </select>
                </label>

                {visualizacao === "QR" && (
                  <label>
                    <span style={labelStyle}>
                      CONFIRMAÇÃO
                    </span>

                    <select
                      value={confirmacaoFiltro}
                      onChange={(e) => {
                        setConfirmacaoFiltro(
                          e.target.value as
                            | "TODOS"
                            | "CONFIRMADOS"
                            | "NAO_CONFIRMADOS"
                        );
                        setIndiceQr(0);
                      }}
                      style={{ width: "100%" }}
                    >
                      <option value="TODOS">
                        Todos
                      </option>
                      <option value="CONFIRMADOS">
                        Confirmados
                      </option>
                      <option value="NAO_CONFIRMADOS">
                        Não confirmados
                      </option>
                    </select>
                  </label>
                )}
              </div>

              <div
                style={{
                  marginTop: 16,
                  display: "flex",
                  gap: 8,
                  flexWrap: "wrap",
                }}
              >
                {STATUS_FILTRO.map((item) => {
                  const ativo =
                    statusFiltros.includes(
                      item.status
                    );

                  return (
                    <button
                      key={item.status}
                      onClick={() =>
                        toggleStatus(item.status)
                      }
                      style={{
                        border: `1px solid ${item.color}`,
                        background: ativo
                          ? item.color
                          : "#fff",
                        color: ativo
                          ? "#fff"
                          : item.color,
                        padding: "8px 12px",
                        borderRadius: 20,
                        fontWeight: 800,
                        cursor: "pointer",
                        fontSize: 11,
                      }}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          </div>
        )}

        <div
          style={{
            display: "flex",
            gap: 10,
            flexWrap: "wrap",
            marginBottom: 16,
          }}
        >
          <button
            onClick={() =>
              setVisualizacao("QR")
            }
            style={{
              ...botao,
              background:
                visualizacao === "QR"
                  ? "#111827"
                  : "#fff",
              color:
                visualizacao === "QR"
                  ? "#fff"
                  : "#111827",
            }}
          >
            <QrCode size={17} />
            LISTA QR
          </button>

          <button
            onClick={() =>
              setVisualizacao("USUARIOS")
            }
            style={{
              ...botao,
              background:
                visualizacao === "USUARIOS"
                  ? "#111827"
                  : "#fff",
              color:
                visualizacao === "USUARIOS"
                  ? "#fff"
                  : "#111827",
            }}
          >
            <Users size={17} />
            LISTA USUÁRIO
          </button>

          <button
            onClick={() => setVisualizacao("SLA")}
            style={{
              ...botao,
              background:
                visualizacao === "SLA"
                  ? "#111827"
                  : "#fff",
              color:
                visualizacao === "SLA"
                  ? "#fff"
                  : "#111827",
            }}
          >
            <BarChart3 size={17} />
            SLA
          </button>
        </div>

        {!loading && visualizacao === "SLA" && (
          <SlaOperacao
            items={items}
            usuariosMap={usuariosMap}
          />
        )}

        {!loading &&
          visualizacao === "QR" && (
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "minmax(260px,360px) minmax(0,1fr)",
                gap: 10,
              }}
            >
              <div
                className="card"
                style={{
                  padding: 8,
                  maxHeight: "75vh",
                  overflowY: "auto",
                }}
              >
                {baseQr.map((p, index) => (
                  <button
                    key={p.id}
                    onClick={() =>
                      setIndiceQr(index)
                    }
                    style={{
                      width: "100%",
                      textAlign: "left",
                      padding: 8,
                      marginBottom: 4,
                      borderRadius: 10,
                      border:
                        indiceQr === index
                          ? "2px solid #111827"
                          : "1px solid #e5e7eb",
                      background:
                        indiceQr === index
                          ? "#f8fafc"
                          : "#fff",
                      cursor: "pointer",
                    }}
                  >
                    <b
                      style={{
                        display: "block",
                        wordBreak: "break-word",
                      }}
                    >
                      {codigoPacote(p)}
                    </b>

                    <div
                      style={{
                        fontSize: 11,
                        marginTop: 5,
                        color: "#6b7280",
                      }}
                    >
                      {nomeUsuario(
                        p,
                        usuariosMap
                      )}
                    </div>

                    <div
                      style={{ marginTop: 4 }}
                    >
                      <StatusBadge
                        status={p.status}
                      />
                    </div>
                  </button>
                ))}

                {!baseQr.length && (
                  <div
                    style={{
                      padding: 20,
                      textAlign: "center",
                      color: "#9ca3af",
                    }}
                  >
                    Nenhum pacote encontrado.
                  </div>
                )}
              </div>

              {pacoteQr ? (
                <div
                  className="card qr-present"
                  style={{ padding: 16 }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent:
                        "space-between",
                      alignItems: "center",
                      gap: 10,
                      flexWrap: "wrap",
                    }}
                  >
                    <div>
                      <div
                        style={{
                          color: "#6b7280",
                          fontSize: 12,
                        }}
                      >
                        PACOTE {indiceQr + 1} DE{" "}
                        {baseQr.length}
                      </div>

                      <h2
                        style={{
                          margin: "5px 0",
                        }}
                      >
                        {codigoPacote(pacoteQr)}
                      </h2>
                    </div>

                    <StatusBadge
                      status={pacoteQr.status}
                    />
                  </div>

                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      margin: "18px 0",
                      padding: 12,
                      borderRadius: 14,
                      background:
                        (pacoteQr.status ===
                          "ENTREGUE" ||
                          pacoteQr.status ===
                            "AUSENTE") &&
                        pacoteQr.confirmado
                          ? corStatus(
                              pacoteQr.status
                            )
                          : "#fff",
                    }}
                  >
                    <QRCodeSVG
                      value={valorQr(pacoteQr)}
                      size={250}
                      level="H"
                      includeMargin
                      bgColor={
                        pacoteQr.confirmado &&
                        (pacoteQr.status ===
                          "ENTREGUE" ||
                          pacoteQr.status ===
                            "AUSENTE")
                          ? corStatus(
                              pacoteQr.status
                            )
                          : "#fff"
                      }
                      fgColor="#111827"
                    />
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit,minmax(180px,1fr))",
                      gap: 10,
                    }}
                  >
                    <Info
                      titulo="EMPRESA"
                      valor={
                        pacoteQr.empresa || "-"
                      }
                    />

                    <Info
                      titulo="USUÁRIO"
                      valor={nomeUsuario(
                        pacoteQr,
                        usuariosMap
                      )}
                    />

                    <Info
                      titulo="TIPO"
                      valor={nomeTipo(
                        pacoteQr.tipo
                      )}
                    />

                    <Info
                      titulo="STATUS"
                      valor={
                        pacoteQr.status || "-"
                      }
                    />
                  </div>

                  {(pacoteQr.status ===
                    "ENTREGUE" ||
                    pacoteQr.status ===
                      "AUSENTE") && (
                    <div
                      style={{
                        marginTop: 12,
                        padding: 12,
                        borderRadius: 12,
                        background:
                          pacoteQr.confirmado
                            ? pacoteQr.status ===
                              "ENTREGUE"
                              ? "#f0fdf4"
                              : "#fef2f2"
                            : "#f8fafc",
                        border:
                          pacoteQr.confirmado
                            ? `1px solid ${corStatus(
                                pacoteQr.status
                              )}`
                            : "1px solid #e5e7eb",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent:
                            "space-between",
                          gap: 12,
                          flexWrap: "wrap",
                        }}
                      >
                        <div>
                          <strong>
                            {pacoteQr.confirmado
                              ? pacoteQr.status ===
                                "ENTREGUE"
                                ? "MARCAÇÃO ENTREGUE"
                                : "MARCAÇÃO AUSENTE"
                              : pacoteQr.status ===
                                "ENTREGUE"
                                ? "MARCAR ENTREGUE"
                                : "MARCAR AUSENTE"}
                          </strong>

                          <div
                            style={{
                              marginTop: 4,
                              color: "#6b7280",
                              fontSize: 12,
                            }}
                          >
                            Esta marcação apenas confirma
                            o pacote nesta tela.
                          </div>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            gap: 8,
                            flexWrap: "wrap",
                            justifyContent: "flex-end",
                          }}
                        >
                          <button
                          onClick={() =>
                            marcarPacote(pacoteQr)
                          }
                          disabled={
                            salvando ===
                            String(
                              pacoteQr.id ||
                                pacoteQr.codigo ||
                                ""
                            )
                          }
                          style={{
                            border: 0,
                            borderRadius: 10,
                            padding: "11px 16px",
                            background:
                              pacoteQr.confirmado
                                ? corStatus(
                                    pacoteQr.status
                                  )
                                : "#111827",
                            color: "#fff",
                            fontWeight: 800,
                            cursor: "pointer",
                          }}
                        >
                          {salvando ===
                          String(
                            pacoteQr.id ||
                              pacoteQr.codigo ||
                              ""
                          )
                            ? "SALVANDO..."
                            : pacoteQr.confirmado
                              ? "CONFIRMADO"
                              : "CONFIRMAR"}
                          </button>

                          <button
                          type="button"
                          onClick={() =>
                            setPacoteComprovante(pacoteQr)
                          }
                          style={{
                            border: "1px solid #d1d5db",
                            borderRadius: 10,
                            padding: "11px 16px",
                            background: "#fff",
                            color: "#111827",
                            fontWeight: 800,
                            cursor: "pointer",
                          }}
                        >
                          ABRIR COMPROVANTE
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  <div
                    style={{
                      display: "flex",
                      gap: 10,
                      marginTop: 20,
                      justifyContent:
                        "space-between",
                    }}
                  >
                    <button
                      onClick={() =>
                        setIndiceQr((i) =>
                          Math.max(0, i - 1)
                        )
                      }
                      disabled={indiceQr === 0}
                      style={botao}
                    >
                      <ChevronLeft size={18} />
                      ANTERIOR
                    </button>

                    <button
                      onClick={() =>
                        setIndiceQr((i) =>
                          Math.min(
                            baseQr.length - 1,
                            i + 1
                          )
                        )
                      }
                      disabled={
                        indiceQr >= baseQr.length - 1
                      }
                      style={botao}
                    >
                      PRÓXIMO
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="card">
                  Nenhum pacote encontrado.
                </div>
              )}
            </div>
          )}

        {!loading &&
          visualizacao === "USUARIOS" && (
            <div>
              <div
                style={{
                  marginBottom: 16,
                  padding: 14,
                  background: "#eff6ff",
                  borderRadius: 10,
                  color: "#1e40af",
                  fontWeight: 700,
                }}
              >
                A quantidade abaixo respeita todos os
                filtros selecionados.
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(auto-fit,minmax(280px,1fr))",
                  gap: 14,
                }}
              >
                {resumoUsuarios.map((u) => (
                  <div
                    className="card"
                    key={u.id}
                    style={{
                      padding: 18,
                      borderTop:
                        "4px solid #2563eb",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent:
                          "space-between",
                        gap: 12,
                        alignItems: "center",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <div
                          style={{
                            width: 42,
                            height: 42,
                            borderRadius: "50%",
                            display: "grid",
                            placeItems: "center",
                            background: "#eff6ff",
                            color: "#2563eb",
                          }}
                        >
                          <User size={21} />
                        </div>

                        <div>
                          <strong
                            style={{
                              display: "block",
                              color: "#111827",
                            }}
                          >
                            {u.nome}
                          </strong>

                          {u.id !==
                            "__sem_usuario__" && (
                            <small
                              style={{
                                color: "#6b7280",
                              }}
                            >
                              {u.id}
                            </small>
                          )}
                        </div>
                      </div>

                      <div
                        style={{
                          minWidth: 58,
                          height: 58,
                          borderRadius: 12,
                          background: "#111827",
                          color: "#fff",
                          display: "grid",
                          placeItems: "center",
                          textAlign: "center",
                        }}
                      >
                        <div>
                          <strong
                            style={{
                              fontSize: 20,
                            }}
                          >
                            {u.total}
                          </strong>

                          <small
                            style={{
                              display: "block",
                              fontSize: 8,
                            }}
                          >
                            PACOTES
                          </small>
                        </div>
                      </div>
                    </div>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns:
                          "repeat(2,minmax(0,1fr))",
                        gap: 8,
                        marginTop: 16,
                      }}
                    >
                      <Contagem
                        label="ENTREGUE"
                        valor={u.entregue}
                        cor="#16a34a"
                      />

                      <Contagem
                        label="AUSENTE"
                        valor={u.ausente}
                        cor="#ef4444"
                      />

                      <Contagem
                        label="ROTA"
                        valor={u.rota}
                        cor="#2196f3"
                      />

                      <Contagem
                        label="COLETADO"
                        valor={u.coletado}
                        cor="#c9a227"
                      />

                      <Contagem
                        label="DEVOLVIDO"
                        valor={u.devolvido}
                        cor="#6b7280"
                      />
                    </div>
                  </div>
                ))}

                {!resumoUsuarios.length && (
                  <div className="card">
                    Nenhum usuário encontrado com os
                    filtros atuais.
                  </div>
                )}
              </div>
            </div>
          )}

        {loading && (
          <div
            className="card"
            style={{
              padding: 30,
              textAlign: "center",
              color: "#64748b",
            }}
          >
            Carregando operação...
          </div>
        )}

        {pacoteComprovante && (
          <ComprovanteOperacao
            pacote={pacoteComprovante}
            usuariosMap={usuariosMap}
            onFechar={() => setPacoteComprovante(null)}
          />
        )}
      </div>
    </>
  );
}

function ComprovanteOperacao({
  pacote,
  usuariosMap,
  onFechar,
}: {
  pacote: any;
  usuariosMap: Record<string, string>;
  onFechar: () => void;
}) {
  const dados = (() => {
    if (pacote.raw && typeof pacote.raw === "object") {
      return { ...pacote.raw, ...pacote };
    }

    if (typeof pacote.raw === "string") {
      try {
        return {
          ...JSON.parse(pacote.raw),
          ...pacote,
        };
      } catch {
        return pacote;
      }
    }

    return pacote;
  })();
  const enderecoInicial: EnderecoOperacao = {
    rua: String(
      valorOperacao(dados, ["rua", "logradouro", "street"])
    ),
    numero: String(
      valorOperacao(dados, ["numero", "number", "house_number"])
    ),
    bairro: String(
      valorOperacao(dados, [
        "bairro",
        "neighborhood",
        "suburb",
      ])
    ),
    cidade: String(
      valorOperacao(dados, ["cidade", "municipio", "city"])
    ),
    estado: String(
      valorOperacao(dados, ["estado", "uf", "state"])
    ),
    cep: String(
      valorOperacao(dados, ["cep", "CEP", "postcode"])
    ),
  };
  const [fotoSelecionada, setFotoSelecionada] =
    useState<string | null>(null);
  const [enderecoAutomatico, setEnderecoAutomatico] =
    useState<EnderecoOperacao>(enderecoInicial);
  const [buscandoEndereco, setBuscandoEndereco] =
    useState(false);
  const fotos = Array.from(
    new Set(
      [
        ...(Array.isArray(dados.fotos) ? dados.fotos : []),
        dados.fotoUrl,
        dados.fotoEntrega,
        dados.fotoEntregue,
        dados.foto,
        dados.imagem,
        dados.comprovanteFoto,
      ]
        .map((foto) => String(foto || "").trim())
        .filter(Boolean)
    )
  );
  const usuario = usuarioId(pacote);
  const entregador =
    dados.usuarioNome ||
    dados.nomeEntregador ||
    usuariosMap[usuario] ||
    usuario ||
    "-";

  useEffect(() => {
    let ativo = true;

    setBuscandoEndereco(true);
    completarEnderecoOperacao(dados)
      .then((endereco) => {
        if (ativo) setEnderecoAutomatico(endereco);
      })
      .finally(() => {
        if (ativo) setBuscandoEndereco(false);
      });

    return () => {
      ativo = false;
    };
  }, [pacote]);

  const historico = Array.isArray(dados.historico)
    ? dados.historico
    : [];
  const nomeRecebedor = String(
    dados.nomeRecebedor ||
      dados.nome_recebedor ||
      dados.recebedor ||
      dados.destinatario ||
      dados.nome ||
      "—"
  );
  const documentoRecebedor = String(
    dados.documentoRecebedor ||
      dados.documento ||
      dados.cpfRecebedor ||
      "—"
  );
  const observacao = String(
    dados.observacao ||
      dados.observação ||
      dados.obs ||
      "—"
  );
  const rua = enderecoAutomatico.rua;
  const numero = enderecoAutomatico.numero;
  const bairro = enderecoAutomatico.bairro;
  const cidade = enderecoAutomatico.cidade;
  const estado = enderecoAutomatico.estado;
  const cep = enderecoAutomatico.cep;
  const enderecoCompleto = [
    rua,
    numero,
    bairro,
    cidade,
    estado,
    cep,
  ]
    .filter(Boolean)
    .join(", ");
  const latitude = Number(
    dados?.latitudeEntrega ??
      dados?.latitude ??
      dados?.lat
  );
  const longitude = Number(
    dados?.longitudeEntrega ??
      dados?.longitude ??
      dados?.lng
  );
  const dataEntrega =
    dados.dataHoraBaixa ||
    dados.dataHoraEntrega ||
    dados.dataEntrega ||
    dados.dataHora ||
    dados.data;
  const formatarDataOperacao = (data: any) => {
    const milissegundos = timestampMs(data);
    return Number.isFinite(milissegundos)
      ? new Date(milissegundos).toLocaleString("pt-BR")
      : String(data || "—");
  };
  const alturaHistorico = historico.length ? 122 : 64;
  const pontosHistorico = historico.map(
    (_item: any, index: number) => ({
      ...pontoHistoricoOperacao(
        index,
        historico.length
      ),
    })
  );

  // Mantém o comprovante compacto e na mesma ordem do rastreamento.
  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onFechar}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 10000,
        background: "rgba(15,23,42,.60)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 12,
      }}
    >
      <article
        onClick={(event) => event.stopPropagation()}
        style={{
          width: "min(96vw, 940px)",
          maxHeight: "94vh",
          overflowY: "auto",
          background: "#fff",
          borderRadius: 14,
          boxShadow: "0 25px 70px rgba(15,23,42,.35)",
        }}
      >
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 10,
            padding: "12px 14px",
            borderBottom: "1px solid #edf0f3",
          }}
        >
          <div>
            <small
              style={{
                color: "#9a7209",
                fontWeight: 800,
                letterSpacing: ".08em",
              }}
            >
              COMPROVANTE DE ENTREGA
            </small>
            <h2
              style={{
                margin: "3px 0 0",
                color: "#17202d",
                fontSize: 18,
              }}
            >
              {codigoPacote(pacote)}
            </h2>
          </div>
          <button
            type="button"
            onClick={onFechar}
            aria-label="Fechar comprovante"
            style={{
              width: 32,
              height: 32,
              display: "grid",
              placeItems: "center",
              border: "1px solid #e2e8f0",
              borderRadius: 8,
              background: "#f8fafc",
              cursor: "pointer",
            }}
          >
            <X size={17} />
          </button>
        </header>

        <div className="comprovante-operacao-linha">
          <section className="comprovante-operacao-secao">
            <div className="comprovante-operacao-titulo">
              <Package size={16} />
              Identificação
            </div>
            <div className="comprovante-operacao-info">
              <Info
                titulo="STATUS"
                valor={String(pacote.status || "—")}
              />
              <Info
                titulo="TIPO"
                valor={nomeTipo(pacote.tipo)}
              />
              <Info
                titulo="EMPRESA"
                valor={String(pacote.empresa || "—")}
              />
              <Info
                titulo="ENTREGADOR"
                valor={entregador}
              />
              <Info
                titulo="DATA DA ENTREGA"
                valor={formatarDataOperacao(dataEntrega)}
              />
            </div>
          </section>

          <section className="comprovante-operacao-secao">
            <div className="comprovante-operacao-titulo">
              <History size={16} />
              Histórico da encomenda
            </div>
            {historico.length > 0 ? (
              <div
                className="comprovante-operacao-historico"
                style={{
                  minHeight: alturaHistorico,
                }}
              >
                <svg
                  className="comprovante-operacao-trilha"
                  viewBox={`0 0 360 ${alturaHistorico}`}
                  preserveAspectRatio="none"
                  aria-hidden="true"
                >
                  {pontosHistorico
                    .slice(0, -1)
                    .map(
                      (
                        ponto: { x: number; y: number },
                        index: number
                      ) => {
                      const proximo =
                        pontosHistorico[index + 1];
                      if (!proximo) return null;
                      const meioX =
                        (ponto.x + proximo.x) / 2;
                      const caminho =
                        `M ${ponto.x} ${ponto.y} ` +
                        `C ${meioX} ${ponto.y}, ` +
                        `${meioX} ${proximo.y}, ` +
                        `${proximo.x} ${proximo.y}`;

                      return (
                        <path
                          key={index}
                          d={caminho}
                          fill="none"
                          stroke={corHistoricoOperacao(
                            historico[index]?.status
                          )}
                          strokeWidth="3"
                          strokeLinecap="round"
                          opacity=".65"
                        />
                      );
                      }
                    )}
                </svg>
                {historico.map((item: any, index: number) => (
                  <div
                    className="comprovante-operacao-historico-item"
                    key={index}
                    style={{
                      left: `${(pontosHistorico[index].x / 360) * 100}%`,
                      top: pontosHistorico[index].y - 5,
                    }}
                  >
                    <span
                      className="comprovante-operacao-historico-ponto"
                      style={{
                        left: "auto",
                        background: corHistoricoOperacao(
                          item?.status
                        ),
                        boxShadow:
                          `0 0 0 3px ${corHistoricoOperacao(
                            item?.status
                          )}22`,
                      }}
                    />
                    <div>
                      <div
                        className="comprovante-operacao-historico-status"
                        style={{
                          color: corHistoricoOperacao(
                            item?.status
                          ),
                        }}
                      >
                        {item?.status || "Atualização"}
                      </div>
                      <div className="comprovante-operacao-historico-data">
                        {formatarDataOperacao(item?.dataHora)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="sem-foto">
                <History size={17} />
                Nenhum histórico registrado.
              </div>
            )}
          </section>
        </div>

        <div className="comprovante-operacao-linha">
          <section className="comprovante-operacao-secao">
            <div className="comprovante-operacao-titulo">
              <User size={16} />
              Recebedor
            </div>
            <div className="comprovante-operacao-info">
              <Info titulo="NOME" valor={nomeRecebedor} />
              <Info
                titulo="DOCUMENTO"
                valor={documentoRecebedor}
              />
            </div>
            {observacao !== "—" && (
              <div
                style={{
                  marginTop: 6,
                  padding: "8px 10px",
                  border: "1px solid #fef3c7",
                  borderRadius: 8,
                  background: "#fffbeb",
                  color: "#713f12",
                  fontSize: 12,
                  lineHeight: 1.4,
                }}
              >
                {observacao}
              </div>
            )}
          </section>

          <section className="comprovante-operacao-secao">
            <div className="comprovante-operacao-titulo">
              <Camera size={16} />
              Comprovante fotográfico
            </div>
            {fotos.length > 0 ? (
              <div className="comprovante-operacao-fotos">
                {fotos.map((foto, index) => (
                  <img
                    key={`${foto}-${index}`}
                    className="comprovante-operacao-foto"
                    src={foto}
                    alt={`Comprovante ${index + 1}`}
                    onClick={() => setFotoSelecionada(foto)}
                    style={{ cursor: "zoom-in" }}
                  />
                ))}
              </div>
            ) : (
              <div className="sem-foto">
                <Camera size={17} />
                Nenhuma foto registrada.
              </div>
            )}
          </section>
        </div>

        <section className="comprovante-operacao-endereco">
          <div className="comprovante-operacao-titulo">
            <MapPin size={16} />
            Endereço da entrega
          </div>
          {buscandoEndereco && (
            <div className="comprovante-operacao-endereco-carregando">
              Buscando rua, número, bairro, cidade e CEP pelas coordenadas...
            </div>
          )}
          <div className="comprovante-operacao-endereco-grid">
            <div className="info-item comprovante-operacao-endereco-completo">
              <div className="info-label">ENDEREÇO COMPLETO</div>
              <div className="info-valor">
                {enderecoCompleto || "Endereço não informado"}
              </div>
            </div>
            <Info titulo="RUA" valor={rua || "Não informado"} />
            <Info titulo="NÚMERO" valor={numero || "Não informado"} />
            <Info titulo="BAIRRO" valor={bairro || "Não informado"} />
            <Info titulo="CIDADE" valor={cidade || "Não informado"} />
            <Info titulo="ESTADO" valor={estado || "Não informado"} />
            <Info titulo="CEP" valor={cep || "Não informado"} />
          </div>
          {Number.isFinite(latitude) &&
            Number.isFinite(longitude) && (
              <a
                className="comprovante-operacao-mapa"
                href={`https://www.google.com/maps?q=${latitude},${longitude}`}
                target="_blank"
                rel="noreferrer"
              >
                <MapPin size={14} />
                Ver localização no mapa
              </a>
            )}
        </section>
      </article>

      {fotoSelecionada && (
        <div
          className="operacao-modal-foto"
          onClick={() => setFotoSelecionada(null)}
        >
          <button
            type="button"
            className="operacao-modal-foto-fechar"
            onClick={(event) => {
              event.stopPropagation();
              setFotoSelecionada(null);
            }}
            aria-label="Fechar foto ampliada"
          >
            <X size={22} />
          </button>

          {fotos.indexOf(fotoSelecionada) > 0 && (
            <button
              type="button"
              className="operacao-modal-foto-seta esquerda"
              onClick={(event) => {
                event.stopPropagation();
                setFotoSelecionada(
                  fotos[fotos.indexOf(fotoSelecionada) - 1]
                );
              }}
              aria-label="Foto anterior"
            >
              <ChevronLeft size={28} />
            </button>
          )}

          <img
            src={fotoSelecionada}
            alt="Comprovante ampliado"
            onClick={(event) => event.stopPropagation()}
          />

          {fotos.indexOf(fotoSelecionada) <
            fotos.length - 1 && (
            <button
              type="button"
              className="operacao-modal-foto-seta direita"
              onClick={(event) => {
                event.stopPropagation();
                setFotoSelecionada(
                  fotos[fotos.indexOf(fotoSelecionada) + 1]
                );
              }}
              aria-label="Próxima foto"
            >
              <ChevronRight size={28} />
            </button>
          )}
        </div>
      )}
    </div>
  );

  /*
   * Layout anterior mantido apenas como referência durante a transição.
   */
  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onFechar}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 10000,
        background: "rgba(15,23,42,.60)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
    >
      <article
        onClick={(event) => event.stopPropagation()}
        style={{
          width: "min(96vw, 900px)",
          maxHeight: "94vh",
          overflowY: "auto",
          background: "#fff",
          borderRadius: 16,
          padding: 20,
          boxShadow: "0 25px 70px rgba(15,23,42,.35)",
        }}
      >
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 12,
            marginBottom: 16,
          }}
        >
          <div>
            <small
              style={{
                color: "#9a7209",
                fontWeight: 800,
                letterSpacing: ".08em",
              }}
            >
              COMPROVANTE DE ENTREGA
            </small>
            <h2 style={{ margin: "4px 0 0", color: "#17202d" }}>
              {codigoPacote(pacote)}
            </h2>
          </div>
          <button
            type="button"
            onClick={onFechar}
            aria-label="Fechar comprovante"
            style={{
              width: 34,
              height: 34,
              display: "grid",
              placeItems: "center",
              border: "1px solid #e2e8f0",
              borderRadius: 8,
              background: "#f8fafc",
              cursor: "pointer",
            }}
          >
            <X size={18} />
          </button>
        </header>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              fotos.length > 0
                ? "repeat(auto-fit,minmax(280px,1fr))"
                : "1fr",
            gap: 14,
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,minmax(0,1fr))",
              gap: 8,
            }}
          >
            <Info titulo="STATUS" valor={String(pacote.status || "-")} />
            <Info titulo="TIPO" valor={nomeTipo(pacote.tipo)} />
            <Info titulo="EMPRESA" valor={String(pacote.empresa || "-")} />
            <Info titulo="ENTREGADOR" valor={entregador} />
            <Info
              titulo="RECEBEDOR"
              valor={String(
                dados.nomeRecebedor ||
                  dados.recebedor ||
                  dados.destinatario ||
                  dados.nome ||
                  "-"
              )}
            />
            <Info
              titulo="DOCUMENTO"
              valor={String(
                dados.documentoRecebedor ||
                  dados.documento ||
                  "-"
              )}
            />
            <div
              style={{
                gridColumn: "1 / -1",
                padding: 12,
                border: "1px solid #e5e7eb",
                borderRadius: 9,
              }}
            >
              <small style={{ color: "#64748b", fontWeight: 800 }}>
                OBSERVAÇÃO
              </small>
              <div style={{ marginTop: 5, whiteSpace: "pre-wrap" }}>
                {String(
                  dados.observacao ||
                    dados.observações ||
                    "-"
                )}
              </div>
            </div>
          </div>

          {fotos.length > 0 ? (
            <div>
              <small style={{ color: "#64748b", fontWeight: 800 }}>
                COMPROVANTE FOTOGRÁFICO
              </small>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    fotos.length === 1
                      ? "1fr"
                      : "repeat(2,minmax(0,1fr))",
                  gap: 8,
                  marginTop: 8,
                }}
              >
                {fotos.map((foto, index) => (
                  <img
                    key={`${foto}-${index}`}
                    src={foto}
                    alt={`Comprovante ${index + 1}`}
                    style={{
                      width: "100%",
                      maxHeight: 420,
                      objectFit: "contain",
                      border: "1px solid #e5e7eb",
                      borderRadius: 10,
                      background: "#f8fafc",
                    }}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                placeItems: "center",
                minHeight: 160,
                color: "#64748b",
                border: "1px dashed #cbd5e1",
                borderRadius: 10,
              }}
            >
              Nenhuma foto de comprovante encontrada.
            </div>
          )}
        </div>
      </article>
    </div>
  );

}

function Info({
  titulo,
  valor,
}: {
  titulo: string;
  valor: string;
}) {
  return (
    <div
      style={{
        padding: "9px 10px",
        border: "1px solid #e5e7eb",
        borderRadius: 9,
      }}
    >
      <small
        style={{
          display: "block",
          color: "#9ca3af",
          fontWeight: 800,
          fontSize: 10,
        }}
      >
        {titulo}
      </small>

      <strong
        style={{
          display: "block",
          marginTop: 3,
          wordBreak: "break-word",
        }}
      >
        {valor}
      </strong>
    </div>
  );
}

function Contagem({
  label,
  valor,
  cor,
}: {
  label: string;
  valor: number;
  cor: string;
}) {
  return (
    <div
      style={{
        padding: 10,
        borderRadius: 8,
        background: "#f8fafc",
        borderLeft: `4px solid ${cor}`,
      }}
    >
      <small
        style={{
          display: "block",
          color: "#6b7280",
          fontSize: 10,
          fontWeight: 800,
        }}
      >
        {label}
      </small>

      <strong
        style={{
          fontSize: 20,
          color: "#111827",
        }}
      >
        {valor}
      </strong>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  marginBottom: 6,
  fontSize: 11,
  fontWeight: 800,
  color: "#6b7280",
};

const botao: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  padding: "11px 15px",
  borderRadius: 9,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 800,
  cursor: "pointer",
};